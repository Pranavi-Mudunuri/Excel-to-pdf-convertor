import sys
import pandas as pd
import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from PyQt5.QtCore import QObject, pyqtSlot, QUrl
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtQml import QQmlApplicationEngine


class Backend(QObject):
    @pyqtSlot()
    def generate_pdf(self):
        try:
            # Read Excel file
            df = pd.read_excel("Data.xlsx")

            # Setup document
            pagesize = A4
            width, height = pagesize
            margin = 40

            # PDF filename
            pdf_file = "new_output.pdf"

            # Styles
            styles = getSampleStyleSheet()
            normal_style = styles["Normal"]
            title_style = ParagraphStyle(
                "title",
                parent=styles["Heading1"],
                alignment=1,  # center
                fontSize=16,
                spaceAfter=12,
            )

            # Current datetime
            now = datetime.datetime.now()
            now_date = now.strftime("%Y-%m-%d")
            now_time = now.strftime("%H:%M:%S")

            # Header callback function for every page
            def on_page(canvas_obj: canvas.Canvas, doc_obj):
                canvas_obj.saveState()

                # Draw "LOGO" (you can replace this with actual image drawing)
                canvas_obj.setFont("Helvetica-Bold", 10)
                canvas_obj.drawString(margin, height - margin, "LOGO")

                # Title
                canvas_obj.setFont("Helvetica-Bold", 16)
                canvas_obj.drawCentredString(width / 2, height - margin, "Project Report")

                # Date & Time
                canvas_obj.setFont("Helvetica", 10)
                canvas_obj.drawRightString(width - margin, height - margin, f"Date: {now_date}")
                canvas_obj.drawRightString(width - margin, height - margin - 12, f"Time: {now_time}")

                canvas_obj.restoreState()

            # Create PDF document
            doc = SimpleDocTemplate(
                pdf_file,
                pagesize=pagesize,
                leftMargin=margin,
                rightMargin=margin,
                topMargin=margin + 40,  # Extra top space for header
                bottomMargin=margin,
            )

            # Build content
            elements = []

            # Table data
            data = [df.columns.tolist()] + df.values.tolist()

            # Create styled table
            table = Table(data, repeatRows=1)

            table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                        ("FONTSIZE", (0, 0), (-1, -1), 10),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                        ("TOPPADDING", (0, 0), (-1, -1), 6),
                    ]
                )
            )
            elements.append(table)
            elements.append(Spacer(1, 30))

            # Footer placeholders
            footer_data = [
                [Paragraph("Result Test:", normal_style), Spacer(1, 18)],
                [Paragraph("Remark:", normal_style), Spacer(1, 18)],
            ]
            footer_table = Table(
                footer_data,
                colWidths=[100, width - 2 * margin - 100],
                hAlign="LEFT",
            )
            footer_table.setStyle(
                TableStyle(
                    [
                        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
                        ("FONTSIZE", (0, 0), (-1, -1), 12),
                        ("ALIGN", (0, 0), (0, -1), "LEFT"),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                        ("TOPPADDING", (0, 0), (-1, -1), 0),
                    ]
                )
            )
            elements.append(footer_table)
            elements.append(Spacer(1, 30))

            # Tested By / Approved By
            tested_approved_data = [
                [Paragraph("Tested By:", normal_style), Paragraph("Approved By:", normal_style)],
                [Spacer(1, 18), Spacer(1, 18)],
            ]
            tested_approved_table = Table(
                tested_approved_data,
                colWidths=[width / 2 - margin, width / 2 - margin],
            )
            tested_approved_table.setStyle(
                TableStyle(
                    [
                        ("ALIGN", (0, 0), (0, 0), "LEFT"),
                        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                        ("TOPPADDING", (0, 0), (-1, -1), 20),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                    ]
                )
            )
            elements.append(tested_approved_table)
            # Build PDF with header on all pages
            doc.build(elements, onFirstPage=on_page, onLaterPages=on_page)
            print("PDF generated successfully as 'new_output.pdf'")

        except Exception as e:
            print("Error generating PDF:", e)


if __name__ == "__main__":
    app = QGuiApplication(sys.argv)
    engine = QQmlApplicationEngine()

    backend = Backend()
    engine.rootContext().setContextProperty("backend", backend)
    engine.load(QUrl.fromLocalFile("main.qml"))

    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())